import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DespesaService {

    @Autowired
    private DespesaRepository repository;

    // Listar todas as despesas
    public List<Despesa> listarTodas() {
        return repository.findAll();
    }

    // Adicionar uma nova despesa
    public Despesa salvar(Despesa despesa) {
        return repository.save(despesa);
    }

    // Editar uma despesa existente
    public Despesa editar(Long id, Despesa despesaAtualizada) {
        Despesa despesa = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Despesa não encontrada com ID: " + id));
        despesa.setDescricao(despesaAtualizada.getDescricao());
        despesa.setValor(despesaAtualizada.getValor());
        return repository.save(despesa);
    }

    // Excluir uma despesa pelo ID
    public void excluir(Long id) {
        repository.deleteById(id);
    }
}
