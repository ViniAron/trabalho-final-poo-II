package br.edu.univille.poo2.login.core.controller;

import br.edu.univille.poo2.login.core.entity.Cartao;
import br.edu.univille.poo2.login.core.service.CartaoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cartoes")
public class CartaoController {
    @Autowired
    private CartaoService service;

    @GetMapping
    public List<Cartao> listarCartoes() {
        return service.listarTodos();
    }

    @PostMapping
    public Cartao cadastrarCartao(@RequestBody Cartao cartao) {
        return service.salvar(cartao);
    }

    @DeleteMapping("/{id}")
    public void excluirCartao(@PathVariable Long id) {
        service.excluir(id);
    }
    @GetMapping("/ativos")
    public List<Cartao> listarCartoesAtivos() {
        return service.listarTodos().stream()
                .filter(Cartao::isAtivo)
                .toList();
    }
    @GetMapping("/estatisticas")
    public Map<String, Object> obterEstatisticas() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("cartoesAtivos", service.contarCartoesAtivos());
        stats.put("valorTotalFaturas", service.calcularValorTotalFaturas());
        stats.put("melhorCartao", "Nubank"); // Lógica personalizada
        stats.put("melhorDiaCompra", "20/10/2024"); // Lógica personalizada
        stats.put("limiteDisponivel", 20500.50); // Exemplo estático
        return stats;
    }


}
