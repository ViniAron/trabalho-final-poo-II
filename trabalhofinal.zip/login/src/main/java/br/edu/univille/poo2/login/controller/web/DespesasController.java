import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/despesas")
public class DespesaController {

    @Autowired
    private DespesaService service;

    // Rota para exibir todas as despesas
    @GetMapping
    public String listarDespesas(Model model) {
        model.addAttribute("despesas", service.listarTodas());
        return "despesas"; // O HTML é "despesas.html"
    }

    // Rota para adicionar uma nova despesa
    @PostMapping
    public String adicionarDespesa(@ModelAttribute Despesa despesa) {
        // Validação básica (exemplo)
        if (despesa.getDescricao() == null || despesa.getValor() <= 0) {
            throw new IllegalArgumentException("Dados da despesa inválidos.");
        }
        service.salvar(despesa);
        return "redirect:/despesas";
    }

    // Rota para editar uma despesa existente
    @PostMapping("/editar/{id}")
    public String editarDespesa(@PathVariable Long id, @ModelAttribute Despesa despesa) {
        if (!service.existePorId(id)) {
            throw new IllegalArgumentException("Despesa não encontrada.");
        }
        service.editar(id, despesa);
        return "redirect:/despesas";
    }

    // Rota para excluir uma despesa
    @PostMapping("/excluir/{id}")
    public String excluirDespesa(@PathVariable Long id) {
        if (!service.existePorId(id)) {
            throw new IllegalArgumentException("Despesa não encontrada.");
        }
        service.excluir(id);
        return "redirect:/despesas";
    }
}
