package br.edu.univille.poo2.login.settings;

import br.edu.univille.poo2.login.core.entity.User;
import br.edu.univille.poo2.login.core.entity.UserRole;
import br.edu.univille.poo2.login.core.repository.UserRepository;
import br.edu.univille.poo2.login.core.repository.UserRoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class Startup {

    @Autowired
    private UserRoleRepository userRoleRepository;

    @Autowired
    private UserRepository userRepository;

    private final BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();

    @EventListener
    public void onApplicationEvent(ContextRefreshedEvent event) {
        initializeRoles();
        initializeUsers();
    }

    private void initializeRoles() {
        if (userRoleRepository.findAll().isEmpty()) {
            createRole("ROLE_ADMIN", "Administrador de Sistema");
            createRole("ROLE_USER", "Usuário");
            createRole("ROLE_MANAGER", "Gerente");
        }
    }

    private void createRole(String code, String name) {
        UserRole role = new UserRole();
        role.setCode(code);
        role.setName(name);
        userRoleRepository.save(role);
    }

    private void initializeUsers() {
        if (userRepository.findAll().isEmpty()) {
            createUser("admin", "Leanderson André", "ROLE_ADMIN", "senha123");
            createUser("user", "Leanderson André", "ROLE_USER", "senha123");
            createUser("manager", "Leanderson André", "ROLE_MANAGER", "senha123");
        }
    }

    private void createUser(String username, String name, String roleCode, String rawPassword) {
        Optional<UserRole> role = userRoleRepository.findAll().stream()
                .filter(userRole -> userRole.getCode().equals(roleCode))
                .findFirst();

        if (role.isPresent()) {
            User user = new User();
            user.setUsername(username);
            user.setName(name);
            user.setActive(true);
            user.setRole(role.get());
            user.setPassword(bCryptPasswordEncoder.encode(rawPassword));
            userRepository.save(user);
        } else {
            throw new IllegalStateException("Role " + roleCode + " not found in the database.");
        }
    }
}
