import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReceitaService {

    @Autowired
    private ReceitaRepository repository;

    // Listar todas as receitas
    public List<Receita> listarTodas() {
        return repository.findAll();
    }

    // Adicionar uma nova receita
    public Receita salvar(Receita receita) {
        return repository.save(receita);
    }

    // Editar uma receita existente
    public Receita editar(Long id, Receita receitaAtualizada) {
        Receita receita = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Receita não encontrada com ID: " + id));
        receita.setDescricao(receitaAtualizada.getDescricao());
        receita.setValor(receitaAtualizada.getValor());
        return repository.save(receita);
    }

    // Excluir uma receita pelo ID
    public void excluir(Long id) {
        repository.deleteById(id);
    }
}
