package br.edu.univille.poo2.login.controller.web;

import br.edu.univille.poo2.login.core.entity.User;
import br.edu.univille.poo2.login.core.repository.UserRepository;
import br.edu.univille.poo2.login.core.repository.UserRoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import javax.validation.Valid;

@Controller
@RequestMapping("/register")
public class RegistrationController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserRoleRepository roleRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;  // Para codificar a senha

    @GetMapping
    public ModelAndView registrationPage() {
        return new ModelAndView("register");
    }

    @PostMapping
    public String registerUser(@Valid @RequestParam String username,
                               @Valid @RequestParam String name,
                               @Valid @RequestParam String password,
                               Model model) {
        // Validação: Verificar se o nome de usuário já existe
        if (userRepository.existsByUsername(username)) {
            model.addAttribute("error", "Nome de usuário já está em uso!");
            return "register";
        }

        // Criação do novo usuário
        User user = new User();
        user.setUsername(username);
        user.setName(name);
        user.setPassword(passwordEncoder.encode(password));  // Hash da senha
        user.setRole(roleRepository.findById(1L).orElseThrow()); // Role "USER"
        user.setActive(true);

        // Salvar usuário no repositório
        userRepository.save(user);

        // Redirecionar para a página de login
        return "redirect:/login";
    }
}
