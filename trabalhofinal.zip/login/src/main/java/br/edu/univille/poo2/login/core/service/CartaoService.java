package br.edu.univille.poo2.login.core.service;

import br.edu.univille.poo2.login.core.entity.Cartao;
import br.edu.univille.poo2.login.core.repository.CartaoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CartaoService {
    @Autowired
    private CartaoRepository repository;

    public List<Cartao> listarTodos() {
        return repository.findAll();
    }

    public Cartao salvar(Cartao cartao) {
        return repository.save(cartao);
    }

    public void excluir(Long id) {
        repository.deleteById(id);
    }
    public long contarCartoesAtivos() {
        return repository.findAll().stream().filter(Cartao::isAtivo).count();
    }

    public double calcularValorTotalFaturas() {
        return repository.findAll().stream()
                .mapToDouble(cartao -> /* Valor da fatura do cartão */)
                .sum();
    }

}
