package br.edu.univille.poo2.login.core.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
@Entity
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // Identificador único do usuário.

    @Column(nullable = false, unique = true)
    private String username; // Nome de usuário (único).

    @Column(nullable = false)
    private String name; // Nome completo do usuário.

    @Column(nullable = false)
    private String password; // Senha (armazenar com hash em produção).

    @Column(nullable = false)
    private boolean active; // Status ativo ou inativo do usuário.

    @ManyToOne(fetch = FetchType.LAZY) // Muitos usuários podem ter o mesmo papel.
    @JoinColumn(name = "role_id", nullable = false)
    private UserRole role; // Associação com o papel do usuário.
}
